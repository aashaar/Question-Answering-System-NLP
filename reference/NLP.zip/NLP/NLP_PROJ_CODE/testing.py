
import spacy
nlp = spacy.load("en")


def printPOS(statement):
    doc = nlp(statement)
    print("\n\n-------------General info------")
    for token in doc:
        print(token.text, token.lemma_, token.pos_, token.tag_, token.dep_,
              token.shape_, token.is_alpha, token.is_stop)


if __name__ == '__main__':
    print("hello")
    printPOS("Nothing really special here.")

