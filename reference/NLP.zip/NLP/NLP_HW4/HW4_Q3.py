import nltk
from nltk.corpus import wordnet as wn
import sys


def get_tokenized_examples(examples):
    """
    This will return set of tokens in all examples.
    """
    result = set()
    for example in examples:
        result = result.union(set(nltk.word_tokenize(str(example))))
        nltk.sent_tokenize()
    return result

def getFunctionAndStopWords():
    """
    :return: set of tokens with stop words and functions.
    """
    return {"a", "about", "above", "across", "after", "again", "against", "all", "along", "although", "always", "am",
            "an", "and", "another", "any", "anyone", "anything", "anyway", "are", "around", "as", "at", "be", "because",
            "been", "before", "behind", "being", "below", "beside", "besides", "between", "both", "but", "by", "can",
            "could", "despite", "did", "do", "does", "doing", "don", "down", "during", "each", "else", "every",
            "everyone", "everything", "few", "first", "for", "from", "further", "had", "half", "has", "have", "having",
            "he", "her", "here", "hers", "herself", "him", "himself", "his", "how", "however", "i", "if", "in",
            "incidentally", "inside", "instead", "into", "is", "it", "its", "itself", "just", "last", "least", "less",
            "little", "many", "may", "me", "meanwhile", "might", "more", "moreover", "most", "much", "must", "my",
            "myself", "near", "never", "next", "no", "nor", "not", "nothing", "now", "of", "off", "often", "on", "once",
            "one", "ones", "only", "onto", "or", "other", "otherwise", "our", "ours", "ourselves", "out", "over", "own",
            "s", "same", "second", "several", "shall", "she", "should", "since", "so", "some", "someone", "something",
            "sometimes", "such", "t", "than", "that", "the", "their", "theirs", "them", "themselves", "then", "there",
            "therefore", "these", "they", "this", "those", "though", "through", "to", "too", "toward", "twice", "two",
            "under", "until", "up", "usually", "very", "was", "we", "were", "what", "when", "where", "which", "while",
            "who", "whom", "whose", "why", "will", "with", "within", "without", "would", "you", "your", "yours",
            "yourself", "yourselves"}

def remove_function_and_stop_words(allTokens):
    """
    This will remove stop words and function words from the allTokens.
    :param allTokens:
    :return: clean tokens
    """
    functionAndStopWords = getFunctionAndStopWords()
    filtered = [x for x in set(allTokens) if x not in functionAndStopWords]
    return set(filtered)

def getSenseSignature(sense):
    """
    This will return set of all tokens in sense definition and examples.
    :param sense: target sense of which signature is required.
    :return: set of all tokens in sense definition and examples.
    """
    definitionTokens = set(nltk.word_tokenize(str(sense.definition())))
    exampleTokens = get_tokenized_examples(sense.examples())
    allTokens = definitionTokens.union(exampleTokens)
    cleanTokens = remove_function_and_stop_words(allTokens)
    return cleanTokens


def computeOverlap(context, signature):
    """
    This will compute overlap
    :param context:
    :param signature:
    :return: number of overlap words
    """
    overlapSet = signature.intersection(context)
    print("Overlap: "+str(len(overlapSet))+" =>"+str(overlapSet))
    return len(overlapSet)


def simplifiedLesk(word, sentence):
    max_overlap = 0
    context = set(nltk.word_tokenize(sentence.lower()))
    allSenses = wn.synsets(word)
    bestSense = allSenses[0]

    for sense in allSenses:
        signature = getSenseSignature(sense)
        print("\n"+str(sense))
        overlap = computeOverlap(context, signature)
        if overlap > max_overlap:
            bestSense = sense
            max_overlap = overlap

    return bestSense


if __name__ == '__main__':
    word = "bank"
    sentence = "The bank can guarantee deposits will eventually cover future tuition costs because it invests in adjustable-rate mortgage securities."
    listA = sys.argv
    if len(sys.argv) > 0 and len(sys.argv) == 3:
        word = sys.argv[1]
        sentence = sys.argv[2]

    resultSense = simplifiedLesk(word, sentence)
    print("---------\nBest Sense is: " + str(resultSense))
    print("Definition: " + str(resultSense.definition()))
    print("Example(s): " + str(resultSense.examples()))
