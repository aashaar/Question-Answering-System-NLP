import java.io.*;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class Q2 {
    static HashMap<String, Integer> unigramCountsMap = new HashMap<>();
    static HashMap<String, Integer> bigramCountsMap = new HashMap<>();
    static HashMap<String, Double> addOneReconstitutedCountMap = new HashMap<>();
    static HashMap<String, Double> tokensMarginalProbabilities = new HashMap<>();
    static HashMap<String, Double> pairsMarginalProbabilities = new HashMap<>();
    static HashMap<String, Double> normalConditionalProbabilities = new HashMap<>();
    static HashMap<String, Double> addOneConditionalProbabilities = new HashMap<>();
    static HashMap<String, Double> goodTuringConditionalProbabilities = new HashMap<>();
    static double goodTuringc0Probability = 0.0;
    static HashMap<Integer, Integer> NMap = new HashMap<>();
    static int totalBigramCount = 0;
    static int totalDistinctBigramCount = 0;
    static int totalUnigramCount = 0;
    static int totalDistinctUnigramCount = 0;
    static String divider = "###";
    static FileWriter fw = null;


    /**
     * Execution entry point
     */
    public static void main(String[] args) {
        if(args.length==0){
            System.out.println("Missing input file path argument");
            return;
        }
        openFileWriter();
        readInputFileAndCalculateCounts(args[0]);
        calculateMarginalProbabilities();
        calculateNormalConditionalProbabilities();
        calculateAddOneReconstitutedCount();
        calculateAddOneConditionalProbabilities();
        prepareNMap();
        calculateGoodTuringConditionalProbabilities();
        printWordCounts();
        printPairCounts();
        printNormalConditionalProb();
        printAddOneReconstitutedCount();
        printAddOneConditionalProb();
        printNMap();
        printGoodTuringConditionalProb();
        closeFileWriter();
    }

    private static void calculateAddOneReconstitutedCount() {
        for (Map.Entry<String, Integer> entry : bigramCountsMap.entrySet()) {
            String[] words = entry.getKey().split(divider);
            String currentToken = words[1];
            String givenToken = words[0];
            int deno = (unigramCountsMap.get(givenToken) + totalDistinctUnigramCount);
            double reconstitutedCount = ((double) entry.getValue() + 1) * unigramCountsMap.get(givenToken) / deno;
            addOneReconstitutedCountMap.put(getPairKey(givenToken, currentToken),reconstitutedCount);
        }
    }

    private static void printGoodTuringConditionalProb() {
        writeLineToFile("--------Good turing Conditional Probs");
        for (Map.Entry<String, Double> entry : goodTuringConditionalProbabilities.entrySet()) {
            writeLineToFile("goodTuringProb" + entry.getKey() + " = " + new BigDecimal(entry.getValue()).toPlainString());
        }
    }

    private static void printAddOneReconstitutedCount() {
        writeLineToFile("--------Add One Reconstituted Counts");
        for (Map.Entry<String, Double> entry : addOneReconstitutedCountMap.entrySet()) {
            String[] tokens = entry.getKey().split(divider);
            String word1 = tokens[0];
            String word2 = tokens[1];
            writeLineToFile("addOneReconstitutedCount('"+ word1+"', '"+word2+"') = " + new BigDecimal(entry.getValue()).toPlainString());
        }
    }

    private static void calculateGoodTuringConditionalProbabilities() {
        goodTuringc0Probability = getNcValue(1) / totalBigramCount;
        for (Map.Entry<String, Integer> entry : bigramCountsMap.entrySet()) {
            int c = entry.getValue();
            double nc = getNcValue(c);
            double ncPlus1 = getNcValue(c + 1);
            String[] words = entry.getKey().split(divider);
            String currentToken = words[1];
            String givenToken = words[0];
            double probability = ((c + 1) * ncPlus1) / (nc * totalBigramCount);
            goodTuringConditionalProbabilities.put(getConditionalProbPairKey(currentToken, givenToken), probability);
        }
    }

    private static double getNcValue(int i) {
        if (NMap.containsKey(i)) {
            return NMap.get(i);
        } else {
            return 0;
        }
    }

    private static void printNMap() {
        writeLineToFile("---------- NMap");
        for (Map.Entry<Integer, Integer> entry : NMap.entrySet()) {
            writeLineToFile("N(" + entry.getKey() + ") = " + entry.getValue());
        }
    }

    /**
     * This generates frequency of bigram frequencies
     */
    private static void prepareNMap() {
        for (Map.Entry<String, Integer> entry : bigramCountsMap.entrySet()) {
            int c = entry.getValue();
            if (NMap.containsKey(c)) {
                NMap.put(c, NMap.get(c) + 1);
            } else {
                NMap.put(c, 1);
            }
        }
    }

    private static void calculateAddOneConditionalProbabilities() {
        for (Map.Entry<String, Integer> entry : bigramCountsMap.entrySet()) {
            String[] words = entry.getKey().split(divider);
            String currentToken = words[1];
            String givenToken = words[0];
            int deno = (unigramCountsMap.get(givenToken) + totalDistinctUnigramCount);
            double conditionalProbability = ((double) entry.getValue() + 1) / deno;
            addOneConditionalProbabilities.put(getConditionalProbPairKey(currentToken, givenToken), conditionalProbability);
        }
    }

    private static void closeFileWriter() {
        try {
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void openFileWriter() {

        try {
            fw = new FileWriter("hbb170030_HW2_Q2_output.txt", false);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void writeLineToFile(String line) {
        System.out.println(line);
        try {
            fw.write(line + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void calculateNormalConditionalProbabilities() {
        for (Map.Entry<String, Integer> entry : bigramCountsMap.entrySet()) {
            String[] words = entry.getKey().split(divider);
            String currentToken = words[1];
            String givenToken = words[0];
            double probability = (double) entry.getValue() / unigramCountsMap.get(givenToken);
            normalConditionalProbabilities.put(getConditionalProbPairKey(currentToken, givenToken), probability);
        }
    }

    private static void calculateMarginalProbabilities() {
        //for words
        for (Map.Entry<String, Integer> entry : unigramCountsMap.entrySet()) {
            tokensMarginalProbabilities.put(entry.getKey(), (double) entry.getValue() / totalUnigramCount);
        }

        //for pairs
        for (Map.Entry<String, Integer> entry : bigramCountsMap.entrySet()) {
            pairsMarginalProbabilities.put(entry.getKey(), (double) entry.getValue() / totalBigramCount);
        }
    }

    private static void printWordCounts() {
        writeLineToFile("-------- Unigram Counts ------");
        for (Map.Entry<String, Integer> entry : unigramCountsMap.entrySet()) {
            writeLineToFile("unigramCount(" + entry.getKey() + ") = " + entry.getValue());
        }
    }


    private static void printPairCounts() {
        writeLineToFile("-------- Bigram Counts --------");
        for (Map.Entry<String, Integer> entry : bigramCountsMap.entrySet()) {
            String[] tokens = entry.getKey().split(divider);
            String word1 = tokens[0];
            String word2 = tokens[1];
            writeLineToFile("bigramCount(" + word1 + ", " + word2 + ")" + " = " + entry.getValue());
        }
    }

    private static void printNormalConditionalProb() {
        writeLineToFile("--------Normal Conditional Probs");
        for (Map.Entry<String, Double> entry : normalConditionalProbabilities.entrySet()) {
            writeLineToFile("prob" + entry.getKey() + " = " + new BigDecimal(entry.getValue()).toPlainString());
        }
    }

    private static void printAddOneConditionalProb() {
        writeLineToFile("--------Add one Conditional Probs");
        for (Map.Entry<String, Double> entry : addOneConditionalProbabilities.entrySet()) {
            writeLineToFile("addOneProb" + entry.getKey() + " = " + new BigDecimal(entry.getValue()).toPlainString());
        }
    }

    private static void readInputFileAndCalculateCounts(String filePath) {
        try {

            File f = new File(filePath);

            BufferedReader b = new BufferedReader(new FileReader(f));

            String readLine = "";

            String previousToken = null;
            while ((readLine = b.readLine()) != null) {
                for (String token : readLine.split("  | |\t")) {
                    totalUnigramCount++;
                    //word count
                    if (unigramCountsMap.containsKey(token)) {
                        int currentValue = unigramCountsMap.get(token);
                        unigramCountsMap.put(token, currentValue + 1);
                    } else {
                        totalDistinctUnigramCount++;
                        unigramCountsMap.put(token, 1);
                    }

                    //pair count
                    if (previousToken != null) {
                        totalBigramCount++;
                        String pairKey = getPairKey(previousToken, token);
                        if (bigramCountsMap.containsKey(pairKey)) {
                            bigramCountsMap.put(pairKey, bigramCountsMap.get(pairKey) + 1);
                        } else {
                            totalDistinctBigramCount++;
                            bigramCountsMap.put(pairKey, 1);
                        }
                    }
                    previousToken = token;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Creates key from two tokens. Order matters.
     *
     * @param previousToken
     * @param token
     * @return
     */
    private static String getPairKey(String previousToken, String token) {
        return previousToken + divider + token;
    }

    /**
     * Creates key from two tokens. Order matters.
     *
     * @param currentToken
     * @param givenToken
     * @return
     */
    private static String getConditionalProbPairKey(String currentToken, String givenToken) {
        return "(" + currentToken + "|" + givenToken + ")";
    }


}
