import java.io.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Q3 {
    static List<String> corpusWords;
    static List<String> correctTagging;
    static List<String> currentTagging;
    static HashMap<String, HashMap<String, Integer>> wordsToPossibleTags;
    static HashMap<String, String> wordToMostFrequentTag;
    static HashMap<String, Integer> tagToCountMap;
    static HashMap<String, Double> wordGivenTagProbMap = new HashMap<>();
    static HashMap<String, Double> tagGivenPrevTagProb = new HashMap<>();
    static HashMap<String, Integer> tagPairToCountMap = new HashMap<>();
    static List<Transformation> transformationList = new ArrayList<>();
    static String[] interestedTags = new String[2];
    static FileWriter fw = null;

    /**
     * Execution entry point
     */
    public static void main(String[] args) {
        openFileWriter();
        if (args.length == 0) {
            System.out.println("Missing input file path argument");
            return;
        }
        readFile(args[0]);
        calculateMostFrequentTags();
        initialTagging();
        findUsefulTransformations();
        openFileWriter();
        printTransformations();
        calculateTagCounts();
        calculateWordGivenTagProb();
        calculateTagGivenPrevTagProb();
        printWordGivenTagProb();
        printTagGivenPrevTagProb();
        closeFileWriter();
    }

    private static void printWordGivenTagProb() {
        writeLineToFile("\n\n------  probability(word|tag) -----");
        for (Map.Entry<String, Double> entry : wordGivenTagProbMap.entrySet()) {
            writeLineToFile("prob" + entry.getKey() + " = " + new BigDecimal(entry.getValue()).toPlainString());
        }
    }

    private static void printTagGivenPrevTagProb() {
        writeLineToFile("\n\n------  probability(tag|prevTag) -----");
        for (Map.Entry<String, Double> entry : tagGivenPrevTagProb.entrySet()) {
            writeLineToFile("prob" + entry.getKey() + " = " + new BigDecimal(entry.getValue()).toPlainString());
        }
    }

    private static void calculateTagGivenPrevTagProb() {
        for (Map.Entry<String, Integer> entry : tagPairToCountMap.entrySet()) {
            String givenTag = entry.getKey().split(" ")[0];
            String tag = entry.getKey().split(" ")[1];
            tagGivenPrevTagProb.put("(" + tag + "|" + givenTag + ")", (double) entry.getValue() / tagToCountMap.get(givenTag));
        }
    }

    private static void calculateWordGivenTagProb() {
        for (Map.Entry<String, HashMap<String, Integer>> entry : wordsToPossibleTags.entrySet()) {
            String word = entry.getKey();
            Map<String, Integer> tagsCountMap = entry.getValue();
            for (Map.Entry<String, Integer> tagsCountEntry : tagsCountMap.entrySet()) {
                String tag = tagsCountEntry.getKey();
                Integer count = tagsCountEntry.getValue();
                Integer tagOccurrences = tagToCountMap.get(tag);
                double prob = (double) count / tagOccurrences;
                wordGivenTagProbMap.put("(" + word + "|" + tag + ")", prob);
            }
        }
    }

    /**
     * This will calculate count of each tag
     */
    private static void calculateTagCounts() {
        String prevTag = null;
        tagToCountMap = new HashMap<>();
        tagPairToCountMap = new HashMap<>();
        for (String tag : correctTagging) {
            //tag count
            int count = 0;
            if (tagToCountMap.containsKey(tag)) {
                count = tagToCountMap.get(tag);
            }
            tagToCountMap.put(tag, count + 1);

            //tag pair count
            if (prevTag != null) {
                String key = prevTag + " " + tag;
                int pairCount = 0;
                if (tagPairToCountMap.containsKey(key)) {
                    pairCount = tagPairToCountMap.get(key);
                }
                tagPairToCountMap.put(key, pairCount + 1);
            }
            prevTag = tag;
        }
    }

    private static void findUsefulTransformations() {
        prepareInterestedTags();
        while (transformationList.size() < 5) {
            Transformation nextBestTransformation = getBestTransformation();
            if (nextBestTransformation != null) {
                applyTransformation(nextBestTransformation);
                transformationList.add(nextBestTransformation);
            } else {
                System.out.println("No more transformation found.");
                break;
            }
        }
    }

    private static void openFileWriter() {
        try {
            fw = new FileWriter("hbb170030_HW2_Q3_output.txt", false);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void closeFileWriter() {
        try {
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void writeLineToFile(String line) {
        System.out.println(line);
        try {
            fw.write(line + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void printTransformations() {
        writeLineToFile("------           Transformations (using Brill’s Tagging)        -----");
        for (Transformation transformation : transformationList) {
            writeLineToFile(transformation.log());
        }
        writeLineToFile("---------------------------------------------------------------------");
    }

    private static void applyTransformation(Transformation transformation) {
        for (int i = 1; i < corpusWords.size(); i++) {
            String prevTag = currentTagging.get(i - 1);
            String currentTag = currentTagging.get(i);
            if (currentTag.equals(transformation.fromTag) && prevTag.equals(transformation.prevTag)) {
                currentTagging.set(i, transformation.toTag);
            }
        }
    }

    private static void prepareInterestedTags() {
        interestedTags[0] = "NN";
        interestedTags[1] = "VB";
    }

    private static Transformation getBestTransformation() {
        TagResult bestTagResult = null;
        Transformation bestTransformation = null;
        for (String fromTag : interestedTags) {
            for (String toTag : interestedTags) {
                if (fromTag.equals(toTag)) {
                    continue;
                }
                HashMap<String, Integer> goodTransformationCounts = new HashMap<>();
                HashMap<String, Integer> badTransformationCounts = new HashMap<>();
                for (int i = 1; i < corpusWords.size(); i++) {
                    String previousTag = currentTagging.get(i - 1);
                    if (correctTagging.get(i).equals(toTag) && currentTagging.get(i).equals(fromTag)) {
                        int goodCount = 0;
                        if (goodTransformationCounts.containsKey(previousTag)) {
                            goodCount = goodTransformationCounts.get(previousTag);
                        }
                        goodTransformationCounts.put(previousTag, goodCount + 1);
                    } else if (correctTagging.get(i).equals(fromTag) && currentTagging.get(i).equals(fromTag)) {
                        int badCount = 0;
                        if (badTransformationCounts.containsKey(previousTag)) {
                            badCount = badTransformationCounts.get(previousTag);
                        }
                        badTransformationCounts.put(previousTag, badCount + 1);
                    }
                }

                TagResult possibleTagResult = getBestTagResult(goodTransformationCounts, badTransformationCounts);
                if (possibleTagResult.isValid()) {
                    if (bestTagResult == null || bestTagResult.score < possibleTagResult.score) {
                        bestTagResult = possibleTagResult;
                        bestTransformation = new Transformation(bestTagResult.tag, fromTag, toTag, bestTagResult.score);
                    }
                }
            }
        }
        return bestTransformation;
    }

    /**
     * this will return tag which has max goodTransformCount - badTransformCount
     *
     * @param goodTransformationCounts
     * @param badTransformationCounts
     * @return
     */
    private static TagResult getBestTagResult(HashMap<String, Integer> goodTransformationCounts, HashMap<String, Integer> badTransformationCounts) {
        long bestScore = -(Long.MAX_VALUE);
        String bestTag = "";
        for (Map.Entry<String, Integer> goodTagCountEntry : goodTransformationCounts.entrySet()) {
            String tag = goodTagCountEntry.getKey();
            int goodCount = goodTagCountEntry.getValue();
            int badCount = 0;
            if (badTransformationCounts.containsKey(tag)) {
                badCount = badTransformationCounts.get(tag);
            }
            long score = goodCount - badCount;
            if (score > bestScore) {
                bestScore = score;
                bestTag = tag;
            }
        }

        return new TagResult(bestTag, bestScore);
    }


    private static void initialTagging() {
        currentTagging = new ArrayList<>();
        for (String word : corpusWords) {
            currentTagging.add(wordToMostFrequentTag.get(word));
        }
    }

    /**
     * This will create wordToMostFrequentTag based on most frequent tag for that word.
     * In matter of tie, it will use tag seen first in entry set.
     */
    private static void calculateMostFrequentTags() {
        for (Map.Entry<String, HashMap<String, Integer>> entry : wordsToPossibleTags.entrySet()) {
            String word = entry.getKey();
            int highestFrequency = -1;
            String highFrequencyTag = "";
            for (Map.Entry<String, Integer> tagCountEntry : entry.getValue().entrySet()) {
                if (tagCountEntry.getValue() > highestFrequency) {
                    highestFrequency = tagCountEntry.getValue();
                    highFrequencyTag = tagCountEntry.getKey();
                }
            }
            wordToMostFrequentTag.put(word, highFrequencyTag);
        }
    }

    private static void readFile(String filePath) {
        corpusWords = new ArrayList<>();
        correctTagging = new ArrayList<>();
        wordsToPossibleTags = new HashMap<>();
        wordToMostFrequentTag = new HashMap<>();

        try {
            File f = new File(filePath);
            BufferedReader b = new BufferedReader(new FileReader(f));
            String readLine = "";
            while ((readLine = b.readLine()) != null) {
                for (String wordTagPair : readLine.split(" ")) {
                    String word = wordTagPair.split("_")[0];
                    String tag = wordTagPair.split("_")[1];
                    corpusWords.add(word);
                    correctTagging.add(tag);
                    considerPossibleTagForWord(word, tag);
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * This will add or update tag and it's count for the word in wordsToPossibleTags
     *
     * @param word
     * @param tag
     */
    private static void considerPossibleTagForWord(String word, String tag) {
        if (!wordsToPossibleTags.containsKey(word)) {
            HashMap<String, Integer> possibleTagToCount = new HashMap<>();
            wordsToPossibleTags.put(word, possibleTagToCount);
        }

        HashMap<String, Integer> possibleTagToCount = wordsToPossibleTags.get(word);
        int currentTagCount = 0;
        if (possibleTagToCount.containsKey(tag)) {
            currentTagCount = possibleTagToCount.get(tag);
        }
        possibleTagToCount.put(tag, currentTagCount + 1);
    }

    static class TagResult {
        String tag;
        Long score;

        public TagResult(String tag, Long score) {
            this.tag = tag;
            this.score = score;
        }

        boolean isValid() {
            return tag.length() > 0;
        }
    }

    static class Transformation {
        String prevTag, fromTag, toTag;
        long score;

        public Transformation(String prevTag, String fromTag, String toTag, long score) {
            this.prevTag = prevTag;
            this.fromTag = fromTag;
            this.toTag = toTag;
            this.score = score;
        }

        public String log() {
            return "If previous tag is " + prevTag + " and current tag is " + fromTag + " then change it to " + toTag + " (" + score + ")";
        }
    }
}
