import java.text.ParseException;

public class Q1 {

    static boolean printInfo = false;

    public static void main(String[] messages) {
        double[][] transitionProbabilities = getTransitionProbabilities();
        double[][] likelihoodProb = getLikelihoodProbabilities();

        String observationString = messages[0];
        if (messages.length == 0) {
            showMissingInputError();
            return;
        }

        if (messages.length > 1 && messages[1].equals("-i")) {
            printInfo = true;
        }

        int[] observations = new int[observationString.length() + 1];
        for (int i = 0; i < observationString.length(); i++) {
            try {
                int observation = Integer.parseInt(observationString.charAt(i) + "");
                if (observation == 1 || observation == 2 || observation == 3) {
                    observations[i + 1] = observation;
                } else {
                    showInvalidInputError();
                    return;
                }
            } catch (NumberFormatException ex) {
                showInvalidInputError();
                return;
            }
        }

        executeViterbi(transitionProbabilities, likelihoodProb, observations);
    }

    private static void showInvalidInputError() {
        System.out.println("Observation string can not contain anything other than '1', '2', '3'.");
    }

    private static void showMissingInputError() {
        System.out.println("Observation string consist of '1', '2', '3' is expected as parameter.");
    }

    private static void executeViterbi(double[][] transitionProbabilities, double[][] likelihoodProb, int[] observations) {
        //how to read: viterbi[i][j] means, best probability of state[j] after observation i.
        double viterbi[][] = new double[observations.length][transitionProbabilities.length];
        //state[1] = hot, state[2] = cold
        //initial
        int numberOfStates = transitionProbabilities.length - 1; //to exclude initial probability entry
        int[][] backPointers = new int[observations.length][transitionProbabilities.length]; //at observation i, j state's previous state value
        for (int i = 1; i <= numberOfStates; i++) {
            double transitionProbValue = transitionProbabilities[0][i];
            double likelihoodProbValue = likelihoodProb[observations[1]][i];
            viterbi[1][i] = transitionProbValue * likelihoodProbValue;
        }

        for (int o = 2; o < observations.length; o++) {
            int observation = observations[o];
            for (int i = 1; i <= numberOfStates; i++) {
                int currentState = i;
                double bestValue = 0;
                int bestPreviousState = 0;
                for (int j = 1; j <= numberOfStates; j++) {
                    int previousState = j;
                    double prev = viterbi[o - 1][previousState];
                    double likelihood = likelihoodProb[observation][currentState];
                    double transition = transitionProbabilities[previousState][currentState];
                    double temp = prev * likelihood * transition;
                    if (temp > bestValue) {
                        bestValue = temp;
                        bestPreviousState = j;
                    }
                }
                viterbi[o][currentState] = bestValue;
                backPointers[o][currentState] = bestPreviousState;
            }
        }

        printMatrix("Viterbi Values", viterbi);
        printMatrix("Backpointers", backPointers);

        double bestLastValue = 0;
        int bestLastState = 0;
        for (int i = 1; i <= numberOfStates; i++) {
            if (viterbi[observations.length - 1][i] > bestLastValue) {
                bestLastValue = viterbi[observations.length - 1][i];
                bestLastState = i;
            }
        }
        String bestSequence = "";
        for (int i = backPointers.length - 1; i >= 0; i--) {
            //record last state
            if (bestLastState == 1) {
                bestSequence = " H ->" + bestSequence;
            } else if (bestLastState == 2) {
                bestSequence = " C ->" + bestSequence;
            }
            bestLastState = backPointers[i][bestLastState];
        }

        System.out.println("Best possible sequence ::" + bestSequence.substring(0, bestSequence.length() - 3) + "   with probability =" + bestLastValue + "");

    }

    private static void printMatrix(String message, double[][] viterbi) {
        if (printInfo) {
            System.out.println("-----" + message + "------");
            for (int i = 0; i < viterbi.length; i++) {
                for (int j = 0; j < viterbi[i].length; j++) {
                    System.out.print("|  " + viterbi[i][j] + "   |");
                }
                System.out.println("");
            }
        }
    }

    private static void printMatrix(String message, int[][] matrix) {
        if (printInfo) {
            System.out.println("-----" + message + "------");
            for (int i = 0; i < matrix.length; i++) {
                for (int j = 0; j < matrix[i].length; j++) {
                    System.out.print("|  " + matrix[i][j] + "   |");
                }
                System.out.println("");
            }
        }
    }

    private static double[][] getLikelihoodProbabilities() {
        double[][] probabilities = new double[4][3];
        //prob[i][j] means probability of obeservation[1,2,3] in state j
        //prob(x|1) for state 1
        probabilities[1][1] = 0.2;
        probabilities[2][1] = 0.4;
        probabilities[3][1] = 0.4;

        //prob(x|2) for state 2
        probabilities[1][2] = 0.5;
        probabilities[2][2] = 0.4;
        probabilities[3][2] = 0.1;

        return probabilities;
    }

    private static double[][] getTransitionProbabilities() {
        //prob[i][j] = probability of state j if previous state was i
        double[][] probabilities = new double[3][3];
        //outgoing from 0 (initial)
        probabilities[0][1] = 0.8;
        probabilities[0][2] = 0.2;

        //outgoing from 1
        probabilities[1][1] = 0.7;
        probabilities[1][2] = 0.3;

        //outgoing from 2
        probabilities[2][1] = 0.4;
        probabilities[2][2] = 0.6;

        return probabilities;
    }
}
